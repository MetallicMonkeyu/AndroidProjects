Reference:

I used the starting code given from the lecture.
The web fragment is rewritten and other fragments are similar to the fragment structure.

I also used hints from powerpoint for hw3.

https://stackoverflow.com/questions/3058919/text-to-speechtts-android
This is used for checking how oninit() is used in text to speech.

https://stackoverflow.com/questions/31998507/android-speech-recognition-startactivityforresult-does-not-work
This is used to understand how startActivityForResult relates with onActivityResult.

https://stackoverflow.com/questions/37098465/android-bouncing-ball-using-canvas
This is used to draw moving balls.

I also used Android developer website as reference for listeners, apis and I used hints from powerpoint for hw3.
