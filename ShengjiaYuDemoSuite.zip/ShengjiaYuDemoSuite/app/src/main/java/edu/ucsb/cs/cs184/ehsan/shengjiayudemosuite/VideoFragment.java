package edu.ucsb.cs.cs184.ehsan.shengjiayudemosuite;

import android.net.Uri;
import android.os.Bundle;
import android.support.v4.app.Fragment;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;


/**
 * A simple {@link Fragment} subclass.
 * Activities that contain this fragment must implement the
 * {@link VideoFragment.OnFragmentInteractionListener} interface
 * to handle interaction events.
 * Use the {@link VideoFragment#newInstance} factory method to
 * create an instance of this fragment.
 */
import android.support.design.widget.FloatingActionButton;
import android.widget.MediaController;
import android.widget.VideoView;




public class VideoFragment extends Fragment {
    // TODO: Rename parameter arguments, choose names that match
    // the fragment initialization parameters, e.g. ARG_ITEM_NUMBER
    private static final String ARG_PARAM1 = "param1";
    private static final String ARG_PARAM2 = "param2";
    boolean isPlay = false;


    public VideoFragment() {
        // Required empty public constructor
    }


    // TODO: Rename and change types and number of parameters
    public static VideoFragment newInstance(String param1, String param2) {
        VideoFragment fragment = new VideoFragment();
        Bundle args = new Bundle();
        args.putString(ARG_PARAM1, param1);
        args.putString(ARG_PARAM2, param2);
        fragment.setArguments(args);
        return fragment;
    }

    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
    }

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container, Bundle savedInstanceState) {
        // Inflate the web_fragment for this fragment
        return inflater.inflate(R.layout.video_fragment, container, false);
    }

    @Override
    public void onActivityCreated(Bundle savedState) {
        super.onActivityCreated(savedState);

        final VideoView videoView = (VideoView) getActivity().findViewById(R.id.videoView);
        videoView.setMediaController(new MediaController(getContext()));
        final Uri video = Uri.parse("android.resource://" + getActivity().getPackageName() +"/" + R.raw.bigbuck);
        videoView.setVideoURI(video);
        final FloatingActionButton button = getActivity().findViewById(R.id.floatingActionButton);
        button.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                if(isPlay){
                    videoView.pause();
                    button.setImageResource(R.drawable.ic_menu_play);
                }else {
                    button.setImageResource(R.drawable.ic_menu_pause);
                    videoView.start();
                }
                isPlay = !isPlay;
            }
        });

    }




}
