package edu.ucsb.cs.cs184.ehsan.shengjiayudemosuite;

import android.graphics.Canvas;
import android.os.Bundle;
import android.support.v4.app.Fragment;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;


public class FireworkFragment extends Fragment {
    // TODO: Rename parameter arguments, choose names that match
    // the fragment initialization parameters, e.g. ARG_ITEM_NUMBER
    private static final String ARG_PARAM1 = "param1";
    private static final String ARG_PARAM2 = "param2";

    // TODO: Rename and change types of parameters
    private String mParam1;
    private String mParam2;

    //private OnFragmentInteractionListener mListener;

    public FireworkFragment() {
        // Required empty public constructor
    }


    public static FireworkFragment newInstance(String param1, String param2) {
        FireworkFragment fragment = new FireworkFragment();
        Bundle args = new Bundle();
        args.putString(ARG_PARAM1, param1);
        args.putString(ARG_PARAM2, param2);
        fragment.setArguments(args);
        return fragment;
    }

    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        if (getArguments() != null) {
            mParam1 = getArguments().getString(ARG_PARAM1);
            mParam2 = getArguments().getString(ARG_PARAM2);
        }
    }

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container, Bundle savedInstanceState) {
        // Inflate the web_fragment for this fragment
        return inflater.inflate(R.layout.firework_fragment, container, false);

    }

    @Override
    public void onActivityCreated(Bundle savedState) {
        Canvas canvas = new Canvas();
        super.onActivityCreated(savedState);
        FireworkView fwView =  getActivity().findViewById(R.id.fireWorkView);
        fwView.draw(canvas);
    }
}