package edu.ucsb.cs.cs184.ehsan.shengjiayudemosuite;

import android.content.Context;
import android.graphics.Canvas;
import android.graphics.Color;
import android.util.AttributeSet;
import android.view.View;

import java.util.ArrayList;
import java.util.Random;

public class FireworkView extends View {

    private ArrayList<Ball> balls = new ArrayList<>();

    public FireworkView(Context context, AttributeSet attrs){
        super(context, attrs);
        init();
    }

    private void init(){
        //Add a new ball to the view
        int [] Direction = new int[] {1,2};
        for(int i = 0; i < 10; i++) {
            balls.add(new Ball(new Random().nextInt(100)+500, new Random().nextInt(100)+500, 50, Color.RED, Direction[new Random().nextInt(Direction.length)], Direction[new Random().nextInt(Direction.length)]));
        }
    }

    @Override
    protected void onDraw(Canvas canvas) {
        super.onDraw(canvas);
        canvas.drawColor(Color.WHITE);

        for(Ball ball : balls){
            //Move first
            ball.move(canvas);
            //Draw them
            canvas.drawOval(ball.oval,ball.paint);
        }
        invalidate(); // See note
    }
}


