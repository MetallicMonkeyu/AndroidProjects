package edu.ucsb.cs.cs184.ehsan.shengjiayudemosuite;

import android.content.ActivityNotFoundException;
import android.content.Intent;
import android.os.Bundle;
import android.speech.RecognizerIntent;
import android.support.annotation.NonNull;
import android.support.annotation.Nullable;
import android.support.v4.app.Fragment;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageButton;
import android.widget.TextView;
import android.widget.Toast;

import java.util.ArrayList;
import java.util.Locale;

import static android.app.Activity.RESULT_OK;


public class SpeechToTextFragment extends Fragment {
    private TextView txtview;
    private ImageButton microp;

    protected static final int REQUESTCODE = 1;
    @Nullable
    @Override
    public View onCreateView(@NonNull LayoutInflater inflater, @Nullable ViewGroup container, @Nullable Bundle savedInstanceState) {
        //url =  getString(R.string.exampleURL);
        View view = inflater.inflate(R.layout.speechtotext_fragment,container,false);
        txtview = (TextView) view.findViewById(R.id.textView);
        microp = (ImageButton) view.findViewById(R.id.imageView);
        microp.setOnClickListener(new View.OnClickListener() {

            public void onClick(View v) {

                Intent intent = new Intent (RecognizerIntent.ACTION_RECOGNIZE_SPEECH);
                intent.putExtra(RecognizerIntent.EXTRA_LANGUAGE, Locale.getDefault());
                intent.putExtra(RecognizerIntent.EXTRA_LANGUAGE_MODEL, RecognizerIntent.LANGUAGE_MODEL_FREE_FORM);
                intent.putExtra(RecognizerIntent.EXTRA_PROMPT,	"Speak now");
                try {
                    startActivityForResult(intent, REQUESTCODE);
                    //txtview.setText("");

                } catch(ActivityNotFoundException anfe){
                    Toast.makeText(getActivity(),
                            "FEATURE NOT SUPPORTED",
                            Toast.LENGTH_SHORT).show();

                }

            }
        });
        return  view;
    }
    @Override
    public void onActivityResult(int requestC, int resultCode, Intent data){
        super.onActivityResult(requestC, resultCode, data);

        Log.e("test1: " ,txtview.getText().toString());
        Log.e("data: ", (data == null)+"");

            Log.e("resultcode",resultCode+"" );
            if (resultCode == RESULT_OK && null!=data){
                ArrayList<String> text = data.getStringArrayListExtra(RecognizerIntent.EXTRA_RESULTS);
                String test = text.get(0);
                Log.e("test: " ,test);
                txtview.setText(text.get(0));
            }

    }

    /*@Override
    protected void onActivityResult(int requestC, int resultCode, Intent data){
        super.onActivityResult(requestC, resultCode, data);
        if (resultCode == requestC){
            if (resultCode == RESULT_OK && null!=data){
                ArrayList<String> text = data.getStringArrayListExtra(RecognizerIntent.EXTRA_RESULTS);
                Log.e("test: " ,text.get(0));
                txtview.setText(text.get(0));
            }
        }
    }*/

}
