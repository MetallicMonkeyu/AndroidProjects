package edu.ucsb.cs.cs184.ehsan.shengjiayudemosuite;

import android.os.Bundle;
import android.speech.tts.TextToSpeech;
import android.support.annotation.NonNull;
import android.support.annotation.Nullable;
import android.support.v4.app.Fragment;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import java.util.Locale;


public class TextToSpeechFragment extends Fragment {
    private EditText edittext;
    TextToSpeech textToSpeech;
    Button bSpeak;
    int result;
    String text;

    @Nullable
    @Override

    public View onCreateView(@NonNull LayoutInflater inflater, @Nullable ViewGroup container, @Nullable Bundle savedInstanceState) {
        //url =  getString(R.string.exampleURL);
        View view = inflater.inflate(R.layout.texttospeech,container,false);
        edittext = (EditText) view.findViewById(R.id.editText);
        final String textToSpeak = edittext.getText().toString();
        textToSpeech = new TextToSpeech(getActivity(), new TextToSpeech.OnInitListener() {
            @Override
            public void onInit(int status) {
                if (status == TextToSpeech.SUCCESS) {
                    int result = textToSpeech.setLanguage(Locale.US);
                    if (result != TextToSpeech.LANG_COUNTRY_AVAILABLE && result != TextToSpeech.LANG_AVAILABLE) {
                        Toast.makeText(getActivity(), "Language not available", Toast.LENGTH_SHORT).show();
                    }
                }
            }
        });

        bSpeak = (Button) view.findViewById(R.id.button);

        bSpeak.setOnClickListener(new View.OnClickListener() {

            public void onClick(View v) {
                if (v.getId()==R.id.button) {

                    if (result == TextToSpeech.LANG_NOT_SUPPORTED || result == TextToSpeech.LANG_MISSING_DATA) {
                        Toast.makeText(getActivity(),
                                "FEATURE NOT SUPPORTED",
                                Toast.LENGTH_SHORT).show();
                    } else {
                        text = edittext.getText().toString();
                        textToSpeech.setPitch(1f);
                        textToSpeech.speak(text, TextToSpeech.QUEUE_FLUSH, null);
                    }
                    //break;
                }

            }
        });
        return  view;
    }
    @Override
    public void onDestroy() {
        super.onDestroy();
        if (textToSpeech != null) {
            textToSpeech.stop();
            textToSpeech.shutdown();
        }
    }






}