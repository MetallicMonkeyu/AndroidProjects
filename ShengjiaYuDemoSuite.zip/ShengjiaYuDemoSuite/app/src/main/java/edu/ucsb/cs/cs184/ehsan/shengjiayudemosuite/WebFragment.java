package edu.ucsb.cs.cs184.ehsan.shengjiayudemosuite;

import android.content.Context;
import android.graphics.Bitmap;
import android.os.Bundle;
import android.support.v4.app.Fragment;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.Toast;

public class WebFragment extends Fragment {
    private ImageView imageView;
    private XkcdRetriever xkcdRetriever;
    private EditText editText;
    private Context context;
    private Button button;


    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        // Inflate the layout for this fragment
        View view = inflater.inflate(R.layout.web_fragment, container, false);
        imageView = view.findViewById(R.id.imageView);
        button = view.findViewById(R.id.button);
        editText = view.findViewById(R.id.editText);

        button.setOnClickListener(new View.OnClickListener() {
            public void onClick(View v) {
                int text = Integer.parseInt(editText.getText().toString());
                if(text > 2062 || text < 1){
                    Toast.makeText(getContext(), "The comic is not available.", Toast.LENGTH_LONG).show();
                    text = (int)(Math.random()*XkcdRetriever.XkcdMaxId)+1;
                }
                XkcdRetriever.getImage(text, new XkcdRetriever.XkcdBitmapResultListener(){
                    @Override
                    public void onImage(Bitmap image){
                        Bitmap mutableImage = image.copy(Bitmap.Config.ARGB_8888, true);
                        imageView.setImageBitmap(mutableImage);
                    }
                });

            }
        });
        return view;
    }

}




