package edu.ucsb.cs.cs184.ehsan.shengjiayudemosuite;

import android.content.Context;
import android.content.pm.ApplicationInfo;
import android.graphics.PorterDuff;
import android.os.Bundle;
import android.speech.tts.TextToSpeech;
import android.support.design.widget.TabLayout;
import android.support.v4.content.ContextCompat;
import android.support.v4.view.ViewPager;
import android.support.v7.app.AppCompatActivity;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

public class MainActivity extends AppCompatActivity {

    private CustomFragmentsPagerAdapter mCustomFragmentsPager;
    private ViewPager mViewPager;
    private TabLayout mTabLayout;
    private Button bSpeak;
    EditText editText;
    private TextToSpeech ttos;
    TextView txtview;
    private int[] tabIcons = {
            R.drawable.ic_menu_share,
            R.drawable.ic_menu_firework,
            R.drawable.ic_menu_video,
            R.drawable.ic_menu_text,
            R.drawable.ic_menu_voice

    };

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);




        mCustomFragmentsPager = new CustomFragmentsPagerAdapter(getSupportFragmentManager());
        mViewPager = (ViewPager) findViewById(R.id.fargmentsPager);
        mTabLayout = (TabLayout) findViewById(R.id.fragmentTabs);
        mTabLayout.setTabMode(TabLayout.MODE_FIXED);
        mTabLayout.setTabGravity(TabLayout.GRAVITY_FILL);


        mTabLayout.addOnTabSelectedListener(new TabLayout.OnTabSelectedListener() {
            @Override
            public void onTabSelected(TabLayout.Tab tab) {
                mViewPager.setCurrentItem(tab.getPosition());
            }

            @Override
            public void onTabUnselected(TabLayout.Tab tab) {

            }

            @Override
            public void onTabReselected(TabLayout.Tab tab) {

            }
        });

        setupViewPager(mViewPager);
        setupTabIcons();

        //A toast to show your package name for us
        Toast.makeText(this, getPackageName(this), Toast.LENGTH_LONG).show();
    }

    private void setupTabIcons() {
        for(int i =0; i< mTabLayout.getTabCount();i++){
            mTabLayout.getTabAt(i).setIcon(tabIcons[i]);
            int tabIconColor = ContextCompat.getColor(this, R.color.colorwhite);
            mTabLayout.getTabAt(i).getIcon().setColorFilter(tabIconColor, PorterDuff.Mode.SRC_IN);
        }
    }

    private  void setupViewPager(ViewPager pager){
        CustomFragmentsPagerAdapter pagerAdapter = new CustomFragmentsPagerAdapter(getSupportFragmentManager());
        WebFragment webFragment = new WebFragment();
        pagerAdapter.addFragment(webFragment,"Browser");
        FireworkFragment fireworkFragment = new FireworkFragment();
        pagerAdapter.addFragment(fireworkFragment,"Firework");
        VideoFragment videoFragment = new VideoFragment();
        pagerAdapter.addFragment(videoFragment,"Video");
        TextToSpeechFragment ttosFragment = new TextToSpeechFragment();
        pagerAdapter.addFragment(ttosFragment,"TextToSpeech");
        SpeechToTextFragment stotFragment = new SpeechToTextFragment();
        pagerAdapter.addFragment(stotFragment,"SpeechToText");
        pager.setAdapter(pagerAdapter);

    }

    // a function to retrieve the package name
    public static String getPackageName(Context context) {
        ApplicationInfo applicationInfo = context.getApplicationInfo();
        return applicationInfo.packageName;
    }


    /*public interface scaleListener{
        public boolean onScale(MotionEvent ev);
    }

    private ArrayList<scaleListener> onScaleListeners = new ArrayList<scaleListener>(10);
    @Override
    public boolean dispatchTouchEvent(MotionEvent ev) {
        for (scaleListener listener : onScaleListeners) {
            if(listener != null) {
                listener.onScale(ev);
            }
        }
        return super.dispatchTouchEvent(ev);
    }
    public void registerMyOnTouchListener(scaleListener myscaleListener) {
        onScaleListeners.add(myscaleListener);
    }
    public void unregisterMyOnTouchListener(scaleListener myscaleListener) {
        onScaleListeners.remove(myscaleListener) ;
    }*/
}





