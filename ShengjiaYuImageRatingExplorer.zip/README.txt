Reference:

I used the starting code given from the lecture.

I also used the code from powerpoint for HW4 for camera and gallery function.

I used reference provided from class website to write a data structure for sqlite to store and build the function of query, update, delete and insert:
https://www.androidhive.info/2011/11/android-sqlite-database-tutorial
http://www.cs.ucsb.edu/~holl/CS184/handouts/ASDEA7-55-57-SQLiteDatabases.pdf

I used this website as reference of saving function used Picasso.
https://square.github.io/picasso/2.x/picasso/com/squareup/picasso/Target.html

I used this sample code for selecting pictures from camera and gallery provided from
https://www.dropbox.com/s/w29sljy0zpwwm61/MyApplication.zip?dl=0&file_subpath=%2FMyApplication%2Fapp%2Fsrc%2Fmain%2Fjava%2Fcom%2Fexample%2Fcool%2Fmyapplication%2FMainActivity.java

I used and revised codes from these websites for recycler tutorial to make gridview dynamically implemented.
https://stackoverflow.com/questions/40587168/simple-android-grid-example-using-recyclerview-with-gridlayoutmanager-like-the
http://www.vogella.com/tutorials/AndroidRecyclerView/article.html

I used codes (getRealPathFromURI_BelowAPI11) for finding path from URI for gallery selection from 
https://gist.github.com/tatocaster/32aad15f6e0c50311626


