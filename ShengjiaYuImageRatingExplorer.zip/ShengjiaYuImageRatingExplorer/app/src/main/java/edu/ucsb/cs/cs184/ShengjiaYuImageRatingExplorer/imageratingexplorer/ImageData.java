package edu.ucsb.cs.cs184.ShengjiaYuImageRatingExplorer.imageratingexplorer;



public class ImageData  {


    public static final String TABLE_NAME = "IMAGE";

    public static final int COLUMN_ID = 0;
    public static final int COLUMN_Rating = 0;
    public static final String COLUMN_URI = "URI";

    String uri;
    int rating;
    int id;

    public static final String CREATE_TABLE =
            "CREATE TABLE " + TABLE_NAME + "("
                    + COLUMN_ID + " INTEGER PRIMARY KEY AUTOINCREMENT,"
                    + COLUMN_URI + " URI,"
                    + COLUMN_Rating + " Rate"
                    + ")";

    public ImageData() {
    }

    public ImageData(int id, String Uri,int rating) {
        this.id = id;
        this.uri = Uri;
        this.rating = rating;
    }

    public String getUri() {
        return uri;
    }

    public void setUri(String uri) {
        this.uri = uri;
    }

    public int getRating() {
        return rating;
    }

    public void setRating(int rating) {
        this.rating = rating;
    }

    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

}
