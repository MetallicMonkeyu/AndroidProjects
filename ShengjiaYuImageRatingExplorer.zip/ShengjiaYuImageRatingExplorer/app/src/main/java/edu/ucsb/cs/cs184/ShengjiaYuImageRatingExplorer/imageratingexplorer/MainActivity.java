package edu.ucsb.cs.cs184.ShengjiaYuImageRatingExplorer.imageratingexplorer;

import android.Manifest;
import android.content.Context;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.content.res.Configuration;
import android.database.Cursor;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.net.Uri;
import android.os.Build;
import android.provider.MediaStore;
import android.os.Bundle;
import android.os.Environment;
import android.support.annotation.RequiresApi;
import android.support.design.widget.FloatingActionButton;
import android.support.v4.app.ActivityCompat;
import android.support.v4.content.ContextCompat;
import android.support.v4.content.FileProvider;
import android.support.v7.app.AppCompatActivity;
import android.support.v7.widget.GridLayoutManager;
import android.support.v7.widget.RecyclerView;
import android.support.v7.widget.Toolbar;
import android.util.Log;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.widget.RatingBar;
import android.widget.Toast;

import com.android.volley.Response;
import com.android.volley.VolleyError;

import org.json.*;

import java.io.File;
import java.io.IOException;
import java.text.SimpleDateFormat;
import java.util.Date;


public class MainActivity extends AppCompatActivity {
    ImageRetriever mImageRetriever;
    RecyclerView recyclerView;
    FloatingActionButton camera;
    FloatingActionButton gallery;
    private String updatedImageName;
    int camRequestCode = 0;
    int galRequestCode = 1;
    RatingBar ratingBar;
    ImageRatingDbHelper dbHelper;
    Toolbar toolbar;
    ImageAdapter adapter;
    boolean shouldExecuteOnResume;
    public static final String imagePath = "ImageRatingPath";
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        Uri imageUri;
        ratingBar = findViewById(R.id.ratingBar);
        ImageRatingDbHelper.initialize(this);
        shouldExecuteOnResume = false;
        dbHelper = ImageRatingDbHelper.getInstance();
        ActivityCompat.requestPermissions(this, new String[]{Manifest.permission.CAMERA,Manifest.permission.WRITE_EXTERNAL_STORAGE}, 1);


        camera = findViewById(R.id.camera);


        camera.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
               /* if (ContextCompat.checkSelfPermission(getApplicationContext(), Manifest.permission.CAMERA) == PackageManager.PERMISSION_DENIED) {
                    Log.d("test", "permission denied");
                    return;
                }*/
                Intent intent = new Intent(MediaStore.ACTION_IMAGE_CAPTURE);
                intent.putExtra(MediaStore.EXTRA_OUTPUT, getPhotoFileUri(newImageFileName()));
                if (intent.resolveActivity(getPackageManager()) != null) {
                    startActivityForResult(intent, camRequestCode);
                }
            }
        });
        gallery = findViewById(R.id.gallery);
        gallery.setOnClickListener(new View.OnClickListener() {
            @RequiresApi(api = Build.VERSION_CODES.M)
            @Override
            public void onClick(View v) {
                if (ContextCompat.checkSelfPermission(getApplicationContext(), Manifest.permission.READ_EXTERNAL_STORAGE) == PackageManager.PERMISSION_DENIED) {
                    requestPermissions(new String[]{Manifest.permission.READ_EXTERNAL_STORAGE}, galRequestCode);
                }
                Intent intent = new Intent(Intent.ACTION_PICK, MediaStore.Images.Media.EXTERNAL_CONTENT_URI);
                startActivityForResult(intent, galRequestCode);
            }
        });
        recyclerView = findViewById(R.id.recyclerView);
        recyclerView.setLayoutManager(new GridLayoutManager(this, 2));
        adapter = new ImageAdapter(this);
        recyclerView.setAdapter(adapter);
        toolbar = findViewById(R.id.toolbar);
        toolbar.setTitle("ImageRatingExplorer");
        setSupportActionBar(toolbar);
        toolbar.setOnMenuItemClickListener(new Toolbar.OnMenuItemClickListener() {
            @Override
            public boolean onMenuItemClick(MenuItem menuItem) {
                switch (menuItem.getItemId()) {
                    case R.id.menu_popular:
                        retrieveData();
                        break;
                    case R.id.menu_clear:
                        dbHelper.delete();
                        break;
                }
                return true;
            }
        });

        ratingBar.setOnRatingBarChangeListener(new RatingBar.OnRatingBarChangeListener() {
            @Override
            public void onRatingChanged(RatingBar ratingBar, float rating, boolean fromUser) {
                adapter.currentRating = (int) rating;
                adapter.refreshRate();
            }
        });


    }
    @Override
    public void onConfigurationChanged(Configuration newConfig) {
        super.onConfigurationChanged(newConfig);
        setGridLayoutColumns(newConfig.orientation);
    }

    private void setGridLayoutColumns(int config){
        recyclerView.setLayoutManager(new GridLayoutManager(this,
                (config == Configuration.ORIENTATION_PORTRAIT) ? 2 : 3));
    }
    @Override
    protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        Uri imageUri = null;
        String path = "";
        Bitmap image= null;
        if (resultCode != RESULT_OK) return;


        switch (requestCode) {

            case 0:
                imageUri = getPhotoFileUri(updatedImageName);
                path = imageUri.getPath();
                Log.d("path:", path);
                path = path.substring(path.indexOf("/storage"));
                image = BitmapFactory.decodeFile(path);
                break;
            case 1:
                imageUri = data.getData();
                path = getGalPathFromURI(this, imageUri);
                try {
                    image = MediaStore.Images.Media.getBitmap(getContentResolver(), imageUri);
                } catch (IOException e) {
                    e.printStackTrace();
                }
            default:
                break;
        }
        dbHelper.insert("file://"+path);

    }


    public Uri getPhotoFileUri(String fileName) {

        if (isExternalStorageAvailable()) {

            File mediaStorageDir = new
                    File( getExternalFilesDir(Environment.DIRECTORY_PICTURES), imagePath);

            if (!mediaStorageDir.exists() && !mediaStorageDir.mkdirs()){
                Log.d(imagePath, "failed to create directory");
            }

            File file = new File(mediaStorageDir.getPath() + File.separator + fileName);

            return FileProvider.getUriForFile(MainActivity.this, "edu.ucsb.cs.cs184.ShengjiaYuImageRatingExplorer.imageratingexplorer.fileprovider", file);
        }
        return null;
    }
    private boolean isExternalStorageAvailable() {
        String state = Environment.getExternalStorageState();
        return state.equals(Environment.MEDIA_MOUNTED);
    }

    private String newImageFileName(){
        updatedImageName = new SimpleDateFormat("yyyyMMdd_HHmmss").format(new Date()) + ".jpg";
        return updatedImageName;
    }

    public static String getGalPathFromURI(Context context, Uri uri) {
        String result = "";
        int column_index = 0;
        String[] proj = { MediaStore.Images.Media.DATA };
        Cursor cursor = context.getContentResolver().query(uri, proj, null, null, null);
        if (cursor != null){
            cursor.moveToFirst();
            column_index = cursor.getColumnIndexOrThrow(MediaStore.Images.Media.DATA);
            result = cursor.getString(column_index);
            cursor.close();
            return result;

        }
        if (result == null) {
            result = "Not found";
        }
        return result;
    }



    private void retrieveData() {
        Log.d("Init", "initializing retriever");

        Toast.makeText(MainActivity.this, "initializing retriever", Toast.LENGTH_SHORT).show();
        mImageRetriever = ImageRetriever.getInstance(this);
        mImageRetriever.listImagesRequest(new Response.Listener<JSONArray>() {
            @Override
            public void onResponse(JSONArray response) {
                try {
                    for (int i = 0; i < response.length(); i++) {
                        JSONObject json = (JSONObject) response.get(i);
                        int height = json.getInt("height");

                        String tem = ((JSONObject) response.get(i)).getString("id");
                        if (height < 1024){
                            int width = json.getInt("width");
                            dbHelper.insert("https://picsum.photos/" + width + "/" + height + "/?image=" + tem);
                        }
                    }
                } catch (Exception e) {
                    Log.d("error", e.toString());
                }
            }
        }, new Response.ErrorListener() {
            @Override
            public void onErrorResponse(VolleyError error) {
                Log.d("error", error.toString());
            }
        });

    }
    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        getMenuInflater().inflate(R.menu.menu_touch, menu);
        return super.onCreateOptionsMenu(menu);
    }

    @Override
    protected void onDestroy() {
        super.onDestroy();
        ImageRatingDbHelper.getInstance().close();
    }

    @Override
    protected void onPostResume() {
        super.onPostResume();
        // Show your dialog here (this is called right after onActivityResult)
        if(shouldExecuteOnResume == true){
            if (adapter.getItemCount()!=0)
                adapter.openDialog(adapter.getItemCount()-1);

        } else{
            shouldExecuteOnResume = true;
        }

    }
}
