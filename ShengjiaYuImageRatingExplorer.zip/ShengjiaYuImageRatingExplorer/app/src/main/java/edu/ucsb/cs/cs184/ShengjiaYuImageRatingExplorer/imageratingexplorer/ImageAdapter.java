
package edu.ucsb.cs.cs184.ShengjiaYuImageRatingExplorer.imageratingexplorer;

import android.app.AlertDialog;
import android.content.Context;
import android.support.v7.widget.RecyclerView;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.RatingBar;

import com.squareup.picasso.Picasso;

import java.util.ArrayList;
import java.util.List;

public class ImageAdapter extends RecyclerView.Adapter<ImageAdapter.ViewHolder> {
    private List<ImageData> imageDataList;
    private Context context_var;
    ImageRatingDbHelper helper;
    int currentRating;
    public static class ViewHolder extends RecyclerView.ViewHolder {

        public ImageView imageView;

        public ViewHolder(View v) {
            super(v);
            imageView = (ImageView) v.findViewById(R.id.imageView);

        }
    }
    public ImageAdapter(Context context) {
        context_var = context;
        imageDataList = new ArrayList<>();
        helper = ImageRatingDbHelper.getInstance();
        helper.subscribe(new ImageRatingDbHelper.OnDatabaseChangeListener() {
            @Override
            public void onDbChange() {
                setData(helper.query(currentRating));
            }
        });
        currentRating = 0;
        setData(helper.query(currentRating));
    }
    @Override
    public ImageAdapter.ViewHolder onCreateViewHolder(ViewGroup parent,
                                                      int viewType) {
        ViewHolder holder = new ViewHolder(LayoutInflater.from(
                parent.getContext()).inflate(R.layout.imagewindow, parent, false));
        return holder;
    }

    @Override
    public void onBindViewHolder(ViewHolder holder, final int position) {
        String uri = imageDataList.get(position).getUri();
        Log.d("uri", "uri: "+uri);
        holder.imageView.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                openDialog(position);
            }
        });
        Picasso.with(context_var).load(uri).resize(400, 400).centerCrop().into(holder.imageView);
    }
    public void openDialog(final int position) {
        String uri = imageDataList.get(position).getUri();
        AlertDialog.Builder customizeDialog = new AlertDialog.Builder(context_var);
        final View popWindow = LayoutInflater.from(context_var).inflate(R.layout.popwindow,null);
        Picasso.with(context_var).load(uri).into((ImageView)popWindow.findViewById(R.id.imageView));
        ((RatingBar) popWindow.findViewById(R.id.ratingBar)).setRating(imageDataList.get(position).getRating());
        ((RatingBar) popWindow.findViewById(R.id.ratingBar)).setOnRatingBarChangeListener(new RatingBar.OnRatingBarChangeListener() {
            @Override
            public void onRatingChanged(RatingBar ratingBar, float rating, boolean fromUser) {
                ImageData tem = imageDataList.get(position);
                helper.update(tem, (int)rating);
            }
        });
        customizeDialog.setView(popWindow);
        customizeDialog.show();
    }
    public void setData(List<ImageData> data) {
        this.imageDataList = data;
        notifyDataSetChanged();
    }
    @Override
    public int getItemCount() {
        return imageDataList.size();
    }
    public void refreshRate() {
        setData(helper.query(currentRating));
    }
}
