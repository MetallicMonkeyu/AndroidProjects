Reference:

I used the starting code given from the lecture.

I also used the code from powerpoint for HW5 for firebase and google map api's permission and functions.

I used this website as reference to retrieve and update the data of firebase.
https://firebase.google.com/docs/database/android/read-and-write#read_and_write_data

I used this website as reference of saving function used Picasso.
https://square.github.io/picasso/2.x/picasso/com/squareup/picasso/Target.html

I used this sample code for hashmap using in firebase android projects.
https://stackoverflow.com/questions/42420997/firebase-push-data-on-same-child-using-hashmap
I also used another site to construct the hashmap inside the helper function, but I accidentally closed it and forgot the address.

I also used used "https://firebase.google.com/ " for other functions of firebase.

I used the following website to create the notification.
https://stackoverflow.com/questions/46990995/on-android-8-1-api-27-notification-does-not-display

I have tried a lot of times in android emulator to debug my project; however, yesterday the emulator did not work for this project any more. I searched on google but no answer worked (even if there was not much I can find regarding the issue). I post the screenshot of the problem on piazza but no one knew the answer. I have to use android template to debug this project. Thus, I am not sure if there is any error during grading while you using the emulator. If you run in issues, please use android device. (I showed Ding about this issue, but we didn't figure it out the reason.)
