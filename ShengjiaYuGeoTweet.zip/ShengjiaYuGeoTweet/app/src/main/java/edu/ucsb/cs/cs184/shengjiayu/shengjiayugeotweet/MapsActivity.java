package edu.ucsb.cs.cs184.shengjiayu.shengjiayugeotweet;

import android.app.AlertDialog;
import android.app.Notification;
import android.app.NotificationChannel;
import android.app.NotificationManager;
import android.app.PendingIntent;
import android.content.Context;
import android.content.Intent;
import android.os.Build;
import android.support.annotation.NonNull;
import android.support.annotation.Nullable;
import android.support.v4.app.FragmentActivity;
import android.os.Bundle;
import android.support.v4.app.NotificationCompat;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;

import com.google.android.gms.maps.CameraUpdateFactory;
import com.google.android.gms.maps.GoogleMap;
import com.google.android.gms.maps.OnMapReadyCallback;
import com.google.android.gms.maps.SupportMapFragment;
import com.google.android.gms.maps.model.BitmapDescriptorFactory;
import com.google.android.gms.maps.model.CameraPosition;
import com.google.android.gms.maps.model.LatLng;
import com.google.android.gms.maps.model.Marker;
import com.google.android.gms.maps.model.MarkerOptions;
import com.google.firebase.database.ChildEventListener;
import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.ValueEventListener;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.Map;

public class MapsActivity extends FragmentActivity implements OnMapReadyCallback,GoogleMap.OnMarkerClickListener {

    private GoogleMap mMap;
    FirebaseHelper helper;
    FirebaseDatabase db;
    double lat, lon;
    ArrayList<ArrayList> data = new ArrayList();
    int i = 0;
    Map<Marker, String> updatesMarker = new HashMap<>();
    Map<String, FirebaseHelper.Message> updatesMessage= new HashMap<>();
    Map<String, FirebaseHelper.Message> deletedMessage= new HashMap<>();
    private NotificationManager notifManager;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_maps);
        // Obtain the SupportMapFragment and get notified when the map is ready to be used.
        SupportMapFragment mapFragment = (SupportMapFragment) getSupportFragmentManager()
                .findFragmentById(R.id.map);
        mapFragment.getMapAsync(this);
        helper.Initialize();
        db = helper.getDb();
    }
    public void createNotification(String author, String content, int likes,  Context context) {
        final int NOTIFY_ID = 0; // ID of notification
        String id = context.getString(R.string.default_notification_channel_id); // default_channel_id
        String title = context.getString(R.string.default_notification_channel_title); // Default Channel
        Intent intent;
        PendingIntent pendingIntent;
        NotificationCompat.Builder builder;
        if (notifManager == null) {
            notifManager = (NotificationManager)context.getSystemService(Context.NOTIFICATION_SERVICE);
        }
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            int importance = NotificationManager.IMPORTANCE_HIGH;
            NotificationChannel mChannel = notifManager.getNotificationChannel(id);
            if (mChannel == null) {
                mChannel = new NotificationChannel(id, title, importance);
                mChannel.enableVibration(true);
                mChannel.setVibrationPattern(new long[]{100, 200, 300, 400, 500, 400, 300, 200, 400});
                notifManager.createNotificationChannel(mChannel);
            }
            builder = new NotificationCompat.Builder(context, id);
            intent = new Intent(context, MapsActivity.class);
            intent.putExtra("likes", likes);
            intent.putExtra("content", content);
            intent.putExtra("author", author);
            intent.setFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP | Intent.FLAG_ACTIVITY_SINGLE_TOP);
            pendingIntent = PendingIntent.getActivity(MapsActivity.this, 0, intent, Intent.FILL_IN_ACTION);
            builder.setContentTitle(author)                            // required
                    .setSmallIcon(android.R.drawable.ic_popup_reminder)   // required
                    .setContentText(content) // required
                    .setDefaults(Notification.DEFAULT_ALL)
                    .setAutoCancel(true)
                    .setContentIntent(pendingIntent)
                    .setTicker(author)
                    .setVibrate(new long[]{100, 200, 300, 400, 500, 400, 300, 200, 400});
        }
        else {
            builder = new NotificationCompat.Builder(context, id);
            intent = new Intent(context, MapsActivity.  class);
            intent.setFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP | Intent.FLAG_ACTIVITY_SINGLE_TOP);
            pendingIntent = PendingIntent.getActivity(MapsActivity.this, 0, intent, Intent.FILL_IN_ACTION);
            builder.setContentTitle(author)                            // required
                    .setSmallIcon(android.R.drawable.ic_popup_reminder)   // required
                    .setContentText(content) // required
                    .setDefaults(Notification.DEFAULT_ALL)
                    .setAutoCancel(true)
                    .setContentIntent(pendingIntent)
                    .setTicker(author)
                    .setVibrate(new long[]{100, 200, 300, 400, 500, 400, 300, 200, 400})
                    .setPriority(Notification.PRIORITY_HIGH);
        }
        Notification notification = builder.build();
        notifManager.notify(NOTIFY_ID, notification);
    }

    /**
     * Manipulates the map once available.
     * This callback is triggered when the map is ready to be used.
     * This is where we can add markers or lines, add listeners or move the camera. In this case,
     * we just add a marker near Sydney, Australia.
     * If Google Play services is not installed on the device, the user will be prompted to install
     * it inside the SupportMapFragment. This method will only be triggered once the user has
     * installed Google Play services and returned to the app.
     */
    @Override
    public void onMapReady(GoogleMap googleMap) {
        mMap = googleMap;

        mMap.setOnMarkerClickListener(this);
        // Add a marker in UCSB and move the camera
        LatLng UCSB = new LatLng(34.412936, -119.847863);
        //mMap.addMarker(new MarkerOptions().position(UCSB).title("Marker in UCSB"));
        //mMap.moveCamera(CameraUpdateFactory.newLatLng(UCSB));
        //mMap.animateCamera(CameraUpdateFactory.zoomTo(14.0f));
        CameraPosition cameraPosition = new CameraPosition.Builder()
                .target(UCSB)     // Sets the center of the map to location user
                .zoom(14)                   // Sets the zoom
                .build();
        mMap.animateCamera(CameraUpdateFactory.newCameraPosition(cameraPosition));


        db.getReference().child("posts")
                .addListenerForSingleValueEvent(new ValueEventListener() {
                    @Override
                    public void onDataChange(DataSnapshot dataSnapshot) {

                        for (DataSnapshot snapshot : dataSnapshot.getChildren()) {
                            //ArrayList<Object> dt = new ArrayList<>();
                            try {
                                FirebaseHelper.Message msg = snapshot.getValue(FirebaseHelper.Message.class);
                                Log.d("Typeee",msg.type);


                                    Marker originMarker = mMap.addMarker(new MarkerOptions().position(new LatLng(msg.latitude, msg.longitude)).icon(BitmapDescriptorFactory.defaultMarker(BitmapDescriptorFactory.HUE_RED)));

                                    //mMap.addMarker(new MarkerOptions().position(new LatLng(msg.latitude, msg.longitude)));
                                    String originkey = dataSnapshot.getKey();
                                    updatesMarker.put(originMarker, originkey);
                                    updatesMessage.put(originkey, msg);
                                    if (msg.type=="bot"){
                                        Log.d("Typeeeee",msg.type);
                                        mMap.addMarker(new MarkerOptions().position(new LatLng(msg.latitude, msg.longitude)).icon(BitmapDescriptorFactory.defaultMarker(BitmapDescriptorFactory.HUE_AZURE)));

                                    }

                            } catch (Exception e){
                                Log.d("Error",e.toString());
                            }

//                            Log.d("The content", msg.content);
                        }
                    }

                    @Override
                    public void onCancelled(DatabaseError databaseError) {
                    }
                });
        final AlertDialog.Builder new_builder = new AlertDialog.Builder(this);


        final LayoutInflater inflater = LayoutInflater.from(this);


        //final AlertDialog show = new_builder.show();
        mMap.setOnMapClickListener(new GoogleMap.OnMapClickListener() {

            @Override
            public void onMapClick(final LatLng point) {
                /*final View popDialog = inflater.inflate(R.layout.dialog,null);
                final EditText txOne = popDialog.findViewById(R.id.text);
                final Button tweetB = popDialog.findViewById(R.id.button_tweet);
                new_builder.setView(popDialog);

                final FirebaseHelper.Message msg = new FirebaseHelper.Message();
                final AlertDialog show = new_builder.show();
                msg.author = "ShengjiaYu";


                msg.timestamp = System.currentTimeMillis();
                msg.longitude = (Double)(point.longitude);
                msg.latitude = point.latitude;
                msg.type = "Student";
                msg.likes = 0;
                mMap.addMarker(new MarkerOptions().position(point).icon(BitmapDescriptorFactory
                        .defaultMarker(BitmapDescriptorFactory.HUE_AZURE)));
                //
                final String a = msg.author;
                final String l = msg.longitude+"";

                //DatabaseReference table = fb.child("posts/-POST_ID_1000");

                tweetB.setOnClickListener(new View.OnClickListener() {
                    @Override
                    public void onClick(View v) {
                        DatabaseReference fb = db.getReference();
                        DatabaseReference table = fb.child("posts");
                        msg.content = txOne.getText().toString();
                        String c = msg.content;
                        //table.push().setValue(msg);
                        table.setValue(new FirebaseHelper.Message(msg.author,msg.content,msg.timestamp,msg.longitude,msg.latitude,msg.type,msg.likes));

                        Log.d("author: ",a);
                        Log.d("lat1: ",l);
                        Log.d("Content",c);
                        show.dismiss();

                    }
                });*/

               // table.push().setValue(new FirebaseHelper.Message(msg.author,msg.content,msg.timestamp,msg.longitude,msg.latitude,msg.type,msg.likes));

                final Marker addedMarker = mMap.addMarker(new MarkerOptions().position(point).icon(BitmapDescriptorFactory
                        .defaultMarker(BitmapDescriptorFactory.HUE_AZURE)));
                final View popDialog = inflater.inflate(R.layout.dialog,null);

                final Button tweetB = popDialog.findViewById(R.id.button_tweet);
                new_builder.setView(popDialog);
                final AlertDialog show = new_builder.show();

                final Button tweetBu = popDialog.findViewById(R.id.button_tweet);



                tweetBu.setOnClickListener(new View.OnClickListener() {
                    @Override
                    public void onClick(View v) {

                        EditText txO = popDialog.findViewById(R.id.text);
                        if (txO.getText().toString()==""){
                            show.dismiss();
                        }
                        FirebaseHelper.Message msg = new FirebaseHelper.Message("Shengjia Yu",txO.getText().toString(),System.currentTimeMillis(),point.longitude,point.latitude,"student",0);
                        Map<String, Object> postValues = msg.toMap();
                        Map<String, Object> childUpdates = new HashMap<>();
                        DatabaseReference fb = db.getReference();
                        String key = fb.child("posts").push().getKey();
                        childUpdates.put("/posts/" + key, postValues);
                        fb.updateChildren(childUpdates);
                        //Log.d("content1: ");
                        updatesMarker.put(addedMarker,key);
                        updatesMessage.put(key,msg);

                        show.dismiss();

                    }
                });

            }

        });
        db.getReference().child("posts").addChildEventListener(new ChildEventListener() {
            @Override
            public void onChildAdded(@NonNull DataSnapshot dataSnapshot, @Nullable String s) {

                String key = dataSnapshot.getKey();
                try {

                        FirebaseHelper.Message msg = dataSnapshot.getValue(FirebaseHelper.Message.class);
                    /*if (msg.type == "bot") {
                        LatLng location = new LatLng(msg.latitude, msg.longitude);
                        Marker marker = mMap.addMarker(new MarkerOptions().position(location).icon(BitmapDescriptorFactory
                                .defaultMarker(BitmapDescriptorFactory.HUE_AZURE)));
                        updatesMarker.put(marker, key);
                        updatesMessage.put(key, msg);
                    } else if (msg.type == "student"){
                        LatLng location = new LatLng(msg.latitude, msg.longitude);
                        Marker marker = mMap.addMarker(new MarkerOptions().position(location).icon(BitmapDescriptorFactory
                                .defaultMarker(BitmapDescriptorFactory.HUE_RED)));
                        updatesMarker.put(marker, key);
                        updatesMessage.put(key, msg);
                    }*/

                        LatLng location = new LatLng(msg.latitude, msg.longitude);
                        Marker marker = mMap.addMarker(new MarkerOptions().position(location).icon(BitmapDescriptorFactory
                                .defaultMarker(BitmapDescriptorFactory.HUE_RED)));
                        updatesMarker.put(marker, key);
                        updatesMessage.put(key, msg);
                        createNotification(msg.author, msg.content, msg.likes, getApplicationContext());



                }catch(Exception e){
                    Log.d("Error",e.toString());
                }
            }

            @Override
            public void onChildChanged(@NonNull DataSnapshot dataSnapshot, @Nullable String s) {

            }

            @Override
            public void onChildRemoved(@NonNull DataSnapshot dataSnapshot) {
                String key = dataSnapshot.getKey();
                Log.d("deleteKey",key);
                try {
                    FirebaseHelper.Message msg = dataSnapshot.getValue(FirebaseHelper.Message.class);

                    Log.d("DCont",msg.content);

                    //createNotification(msg.author, msg.content, msg.likes, getApplicationContext());
                    deletedMessage.put(key,msg);
                }catch(Exception e){
                Log.d("Error",e.toString());
            }

            }

            @Override
            public void onChildMoved(@NonNull DataSnapshot dataSnapshot, @Nullable String s) {

            }

            @Override
            public void onCancelled(@NonNull DatabaseError databaseError) {
                Log.d("ERROR: ", "onCancelled: " + databaseError);

            }
        });

    }
    @Override
    public boolean onMarkerClick(final Marker marker) {

        lat = marker.getPosition().latitude;
        lon = marker.getPosition().longitude;

        AlertDialog.Builder builder = new AlertDialog.Builder(this);
        LayoutInflater inflater = LayoutInflater.from(this);
        final View popTweet = inflater.inflate(R.layout.tweet,null);
        final TextView txOne = popTweet.findViewById(R.id.text1);
        final TextView txTwo = popTweet.findViewById(R.id.text2);
        final TextView txThree = popTweet.findViewById(R.id.text3);
        builder.setView(popTweet);
        final String key = updatesMarker.get(marker);
        /*for (int i = 0; i<data.size();i++){
            if (lat == (Double)((data.get(i)).get(0)) && lon == (Double)((data.get(i)).get(1))){
                txOne.setText( data.get(i).get(2).toString());
                txTwo.setText( data.get(i).get(3).toString());
                txThree.setText( data.get(i).get(4).toString()+" likes");
                Log.d("checkau",data.get(i).get(2).toString());
                Log.d("checkco",data.get(i).get(3).toString());
                Log.d("checklo",data.get(i).get(0).toString());
            }

        }*/
        final Button button = popTweet.findViewById(R.id.button);
        if (deletedMessage.containsKey(key)==false) {

        DatabaseReference fb = db.getReference().child("posts");
        db.getReference().child("posts").child(key).addValueEventListener(new ValueEventListener() {
            @Override
            public void onDataChange(DataSnapshot dataSnapshot) {

                try{
                    FirebaseHelper.Message msg = dataSnapshot.getValue(FirebaseHelper.Message.class);
                    txOne.setText(msg.author);
                    txTwo.setText(msg.content);
                    txThree.setText(msg.likes + " likes");
                }catch(Exception e){
                    Log.d("Error",e.toString());
                }
            }

            @Override
            public void onCancelled(DatabaseError firebaseError) {
                Log.e("Error", firebaseError+"");
            }
        });

       //Log.d("pos",lat+""+lon);
        builder.create().show();



            button.setOnClickListener(new View.OnClickListener() {
                public void onClick(View v) {
                    TextView txThird = popTweet.findViewById(R.id.text3);
                    int likes = Integer.parseInt(txThird.getText().toString().replaceAll("[\\D]", "")) + 1;
                    DatabaseReference updateData = db
                            .getReference("posts")
                            .child(key);
                    updateData.child("likes").setValue(likes);
                    txThird.setText(likes + " likes");
                    //FirebaseHelper.Message msg = snapshot.getValue(FirebaseHelper.Message.class);
                }
            });
        }else if (deletedMessage.containsKey(key)==true){
            FirebaseHelper.Message msg_2 = deletedMessage.get(key);
            txOne.setText(msg_2.author);
            txTwo.setText(msg_2.content);
            txThree.setText(msg_2.likes + " likes");
            button.setEnabled(false);
        }
        //tweet.show(getSupportFragmentManager(), null);
        return true;
    }
}
