package edu.ucsb.cs.cs184.shengjiayu.shengjiayugeotweet;

import com.google.firebase.database.Exclude;
import com.google.firebase.database.FirebaseDatabase;
import java.io.Serializable;
import java.util.HashMap;
import java.util.Map;
/**
 * Created by Donghao Ren on 03/11/2017.
 * Modified by Ehsan Sayyad on 11/9/2018
 */

/**
 * This is a Firebase helper starter class we have created for you
 * In your Activity, please call FirebaseHelper.Initialize() to setup the Firebase
 * Put your application logic in Initialize() and additional methods of your choosing.
 */
public class FirebaseHelper {
    /** This is a message data structure that mirrors our Firebase data structure for your convenience */
    public static class Message implements Serializable {

        public String author;
        public String content;
        public double timestamp;
        public double longitude;
        public double latitude;
        public String type;
        public int likes;

        public Message(){}
        public Message(String author,String content,double timestamp,double longitude,double latitude,String type,int likes){
            this.author = author;
            this.content = content;
            this.timestamp = timestamp;
            this.longitude = longitude;
            this.latitude = latitude;
            this.type = type;
            this.likes = likes;

        }

        public String getAuthor() {
            return author;
        }

        public String getContent() {
            return content;
        }

        public double getTimestamp() {
            return timestamp;
        }

        public double getLongitude() {
            return longitude;
        }

        public double getLatitude() {
            return latitude;
        }

        public String getType() {
            return type;
        }

        public int getLikes() {
            return likes;
        }
        public void setAuthor(String author) {
            this.author = author;
        }

        public void setContent(String content) {
            this.content = content;
        }

        public void setTimestamp(double timestamp) {
            this.timestamp = timestamp;
        }

        public void setLongitude(double longitude) {
            this.longitude = longitude;
        }

        public void setLatitude(double latitude) {
            this.latitude = latitude;
        }

        public void setType(String type) {
            this.type = type;
        }

        public void setLikes(int likes) {
            this.likes = likes;
        }

        @Exclude
        public Map<String, Object> toMap() {
            HashMap<String, Object> result = new HashMap<>();
            result.put("author", author);
            result.put("content", content);
            result.put("timestamp", timestamp);
            result.put("longitude", longitude);
            result.put("latitude", latitude);
            result.put("type", type);
            result.put("likes",likes);
            return result;
        }

    }



    /** The Firebase database object */
    private static FirebaseDatabase db;

    /** This is called once we initialize the firebase database object */
    public static void Initialize() {
        db = FirebaseDatabase.getInstance();

        // TODO: Setup your callbacks to listen for /posts.
        // Your code should handle post added, post updated, and post deleted events.

    }
    public static FirebaseDatabase getDb() {
        return db;
    }
    // TODO: Add methods for increasing the number of likes
    // TODO: You *may* create a listener mechanism so that your Activity and Fragments can register callbacks to the database helper
}
