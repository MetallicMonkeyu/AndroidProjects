Reference:

I used the starting code given from TA.
The surfaceChanged function is overrided.

https://guides.codepath.com/android/Basic-Painting-with-Views
This is used to make the drawPath() function seem smooth.

https://stackoverflow.com/questions/32206317/unboxing-a-boxed-float-to-an-int
This is used for checking unboxing the int type to float type.

I also used Android developer website as reference for listeners of seekbar, typed list and I used hints from powerpoint for hw2.