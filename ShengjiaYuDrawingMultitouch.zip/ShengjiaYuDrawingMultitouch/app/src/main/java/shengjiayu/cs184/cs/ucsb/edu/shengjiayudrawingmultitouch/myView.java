package shengjiayu.cs184.cs.ucsb.edu.shengjiayudrawingmultitouch;


import android.content.Context;
import android.content.res.Resources;
import android.content.res.TypedArray;
import android.graphics.Bitmap;
import android.graphics.Canvas;
import android.graphics.Color;
import android.graphics.Paint;
import android.graphics.Path;
import android.util.AttributeSet;
import android.util.Log;
import android.util.SparseArray;
import android.view.SurfaceView;
import android.view.SurfaceHolder;
import android.view.MotionEvent;
import java.util.ArrayList;



public class myView extends SurfaceView implements SurfaceHolder.Callback {

    private SurfaceHolder holder;
    private Canvas bitmapCanvas = null;
    private Bitmap bitmap_1;


    boolean surfaceExists = false;
    ArrayList<Float> XYList = new ArrayList<Float>();
    Paint style = new Paint();
    float nSize;

    Resources res = getResources();
    TypedArray colors = res.obtainTypedArray(R.array.colors);


    public myView(Context context) {
        super(context);
        holder = this.getHolder();
        holder.addCallback(this);




    }
    public myView(Context context, AttributeSet atts) {

        super(context,atts);
        holder = this.getHolder();
        holder.addCallback(this);


    }
    @Override
    public void surfaceChanged(SurfaceHolder holder, int format, int width,
                               int height) {

        if (bitmapCanvas==null||bitmap_1==null) {

            if (width > height) {
                bitmap_1 = Bitmap.createBitmap(width, width, Bitmap.Config.ARGB_8888);
            } else if (height > width) {
                bitmap_1 = Bitmap.createBitmap(height, height, Bitmap.Config.ARGB_8888);
            }

            bitmapCanvas = new Canvas(bitmap_1);

            bitmapCanvas.drawColor(Color.WHITE);

        }
            refreshView();

    }
    public void refreshView() {
        if(!surfaceExists) return;

        // Draw the painting bitmap to the SurfaceView
        Canvas surfaceCanvas = getHolder().lockCanvas();
        //surfaceCanvas.drawColor(Color.WHITE);
        surfaceCanvas.drawBitmap(bitmap_1, 0, 0, null);
        getHolder().unlockCanvasAndPost(surfaceCanvas);

    }
    @Override
    public void surfaceCreated(SurfaceHolder holder) {
        surfaceExists = true;


    }
    public void clear(){
        bitmapCanvas.drawColor(Color.WHITE);
        refreshView();
    }
    @Override
    public void surfaceDestroyed(SurfaceHolder holder) {

    }
    public void adjustBrushSize(float size){
        //color.setStyle(Paint.Style.FILL);
        nSize = size;

        Log.d("Size", " " + size);
    }




    @Override

    public boolean onTouchEvent(MotionEvent event){


        int random = (int) ((Math.random() * 5 ) );

        style.setStrokeWidth(nSize);
        style.setStyle(Paint.Style.STROKE);
        style.setStrokeJoin(Paint.Join.ROUND);
        style.setStrokeCap(Paint.Cap.ROUND);
        int curPointerIndex = event.getActionIndex();



        if (event.getAction() == MotionEvent.ACTION_DOWN){
            XYList.add(event.getX());
            XYList.add(event.getY());
            XYList.add((float)colors.getColor(random,0));

        }
        if (event.getActionMasked()==MotionEvent.ACTION_POINTER_DOWN){

                XYList.add(event.getX(curPointerIndex));
                XYList.add(event.getY(curPointerIndex));
                XYList.add((float)colors.getColor(random,0));


        }
        else if (event.getActionMasked() == MotionEvent.ACTION_MOVE) {
            int c = event.getPointerCount();
            for (int i = 0 ; i < c; i++){
                Path p = new Path();
                p.moveTo(XYList.get(3*i),XYList.get(3*i+1));
                p.lineTo(event.getX(i),event.getY(i));
                XYList.set(3*i,event.getX(i));
                XYList.set(3*i+1,event.getY(i));

                int thisColor = (int)(float)(XYList.get(3*i+2));
                style.setColor(thisColor);
                bitmapCanvas.drawPath(p,style);

            }
            //Log.d("getcolor",""+style.getColor());
            refreshView();
        } else if(event.getAction() == MotionEvent.ACTION_UP){
            refreshView();
            XYList.clear();

        }

        return true;


    }





}

