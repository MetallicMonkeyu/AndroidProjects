package shengjiayu.cs184.cs.ucsb.edu.shengjiayudrawingmultitouch;


import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.SeekBar;

public class MainActivity extends AppCompatActivity {
    private myView myview = null;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        setContentView(R.layout.activity_main);

        myview = (myView)findViewById(R.id.myView);
        Button but = (Button) findViewById(R.id.button);

        but.setOnClickListener(new View.OnClickListener() {

            public void onClick(View v) {


                myview.clear();


            }
        });
        SeekBar sk= (SeekBar) findViewById(R.id.seekBar);
        sk.setOnSeekBarChangeListener(new SeekBar.OnSeekBarChangeListener() {
            public void onStartTrackingTouch(SeekBar sk) {

            }
            public void onStopTrackingTouch(SeekBar sk){

            }
            public void onProgressChanged(SeekBar seekBar, int progress, boolean fromUser) {


                myview.adjustBrushSize(progress*2);


            }
        });

    }

}
