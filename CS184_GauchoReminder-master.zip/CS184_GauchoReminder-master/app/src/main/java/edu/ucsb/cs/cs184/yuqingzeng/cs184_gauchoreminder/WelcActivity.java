package edu.ucsb.cs.cs184.yuqingzeng.cs184_gauchoreminder;

import android.os.Bundle;
import android.os.Handler;
import android.app.Activity;
import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.content.SharedPreferences.Editor;
import android.util.Log;

public class WelcActivity extends Activity {
    private final int SPLASH_DISPLAY_LENGHT = 5000;
    //private SharedPreferences preferences;
    private Editor editor;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        //preferences = getSharedPreferences("first_time", Context.MODE_PRIVATE);
        new Handler().postDelayed(new Runnable() {

            @Override
            public void run() {
                if (isFirstTime()) {

                    Intent intent = new Intent();
                    intent.setClass(WelcActivity.this,
                            AddGuidePageActivity.class);
                    Log.d("first","first");
                    WelcActivity.this.startActivity(intent);
                    WelcActivity.this.finish();
                } else {
                    setContentView(R.layout.activity_welcome);
                    Intent intent = new Intent();
                    intent.setClass(WelcActivity.this, MainActivity.class);
                    Log.d("later","later");
                    WelcActivity.this.startActivity(intent);
                    WelcActivity.this.finish();

                }

            }
        }, SPLASH_DISPLAY_LENGHT);
    }
    private Boolean firstTime = null;
    /**
     * Checks if the user is opening the app for the first time.
     * Note that this method should be placed inside an activity and it can be called multiple times.
     * @return boolean
     */
    private boolean isFirstTime() {
        if (firstTime == null) {
            SharedPreferences mPreferences = this.getSharedPreferences("first_time", Context.MODE_PRIVATE);
            firstTime = mPreferences.getBoolean("firstTime", true);
            if (firstTime) {
                SharedPreferences.Editor editor = mPreferences.edit();
                editor.putBoolean("firstTime", false);
                editor.commit();
            }
        }
        return firstTime;
    }
}