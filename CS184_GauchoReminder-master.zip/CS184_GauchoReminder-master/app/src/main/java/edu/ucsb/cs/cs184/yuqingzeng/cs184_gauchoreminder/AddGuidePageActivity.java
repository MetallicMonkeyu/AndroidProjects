package edu.ucsb.cs.cs184.yuqingzeng.cs184_gauchoreminder;

import android.app.Activity;
import android.support.v4.view.ViewPager;
import java.util.ArrayList;
import java.util.List;

import android.app.Activity;
import android.content.Intent;
import android.os.Bundle;
import android.support.v4.view.ViewPager;
import android.support.v4.view.ViewPager.OnPageChangeListener;
import android.view.View;
import android.view.View.OnClickListener;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.LinearLayout;

public class AddGuidePageActivity extends Activity implements ViewPager.OnPageChangeListener {
    private ViewPager vp;
    private ViewPagerAdapter vpAdapter;
    private List<View> views;
    private Button button;

    private static final int[] pics = { R.drawable.step1, R.drawable.step2,
            R.drawable.step3, R.drawable.step4 };

    private ImageView[] dots;

    private int currentIndex;

    /** Called when the activity is first created. */
    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_w);

        initView();

        views = new ArrayList<View>();

        LinearLayout.LayoutParams mParams = new LinearLayout.LayoutParams(
                LinearLayout.LayoutParams.WRAP_CONTENT,
                LinearLayout.LayoutParams.WRAP_CONTENT);

        for (int i = 0; i < pics.length; i++) {
            ImageView iv = new ImageView(this);
            iv.setLayoutParams(mParams);
            iv.setImageResource(pics[i]);
            views.add(iv);
        }


        vpAdapter = new ViewPagerAdapter(views);
        vp.setAdapter(vpAdapter);
        vp.setOnPageChangeListener(this);

        button.setOnClickListener(new OnClickListener() {

            @Override
            public void onClick(View arg0) {
                Intent intent = new Intent();
                intent.setClass(AddGuidePageActivity.this, MainActivity.class);
                AddGuidePageActivity.this.startActivity(intent);
                finish();
            }
        });

    }

    private void initView() {
        button = (Button) findViewById(R.id.button);
        vp = (ViewPager) findViewById(R.id.viewpager);
        initDots();
    }

    private void initDots() {
        LinearLayout ll = (LinearLayout) findViewById(R.id.ll);

        dots = new ImageView[pics.length];

        for (int i = 0; i < pics.length; i++) {
            //View android.view.ViewGroup.getChildAt(int index)：
            //Returns the view at the specified position in the group.
            dots[i] = (ImageView) ll.getChildAt(i);
            //dots[i].setEnabled(false);
            dots[i].setAlpha(0.4f);
            dots[i].setTag(i);
        }

        currentIndex = 0;
        //dots[currentIndex].setEnabled(true);
        dots[currentIndex].setAlpha(1f);
    }

    /**
     * change sliding dots
     */
    private void setCurDot(int positon) {
        if (positon < 0 || positon > pics.length - 1 || currentIndex == positon) {
            return;
        }
        System.out.println("positon="+positon);
        //dots[positon].setEnabled(true);
        dots[positon].setAlpha(1f);
        System.out.println("currentIndex="+currentIndex);
        //dots[currentIndex].setEnabled(false);
        dots[currentIndex].setAlpha(0.4f);
        currentIndex = positon;
    }

    @Override
    public void onPageScrollStateChanged(int arg0) {
        // TODO Auto-generated method stub

    }

    @Override
    public void onPageScrolled(int arg0, float arg1, int arg2) {
        // TODO Auto-generated method stub

    }

    @Override
    public void onPageSelected(int arg0) {
        setCurDot(arg0);
        if (arg0 == 3) {
            button.setVisibility(View.VISIBLE);
        } else {
            button.setVisibility(View.GONE);
        }
    }
}
