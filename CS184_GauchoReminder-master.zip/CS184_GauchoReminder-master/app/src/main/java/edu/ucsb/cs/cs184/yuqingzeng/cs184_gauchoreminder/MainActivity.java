package edu.ucsb.cs.cs184.yuqingzeng.cs184_gauchoreminder;

import android.Manifest;
import android.annotation.SuppressLint;
import android.app.Activity;
import android.app.AlertDialog;
import android.app.Instrumentation;
import android.content.ContentResolver;
import android.content.ContentValues;
import android.content.Context;
import android.content.DialogInterface;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.database.Cursor;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.graphics.Color;
import android.graphics.drawable.BitmapDrawable;
import android.net.Uri;
import android.os.AsyncTask;
import android.os.Build;
import android.os.Bundle;
import android.os.Environment;
import android.provider.CalendarContract;
import android.provider.MediaStore;
import android.support.annotation.Nullable;
import android.support.v4.app.ActivityCompat;
import android.support.v4.content.ContextCompat;
import android.support.v4.content.FileProvider;
import android.support.v7.app.AppCompatActivity;
import android.text.SpannableString;
import android.text.Spanned;
import android.text.method.ScrollingMovementMethod;
import android.text.style.BackgroundColorSpan;
import android.util.Log;
import android.util.SparseArray;
import android.view.SurfaceHolder;
import android.view.SurfaceView;
import android.view.View;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;

import com.google.android.gms.vision.CameraSource;
import com.google.android.gms.vision.Detector;
import com.google.android.gms.vision.Frame;
import com.google.android.gms.vision.text.Text;
import com.google.android.gms.vision.text.TextBlock;
import com.google.android.gms.vision.text.TextRecognizer;
import com.google.api.client.extensions.android.json.AndroidJsonFactory;
import com.google.api.client.http.javanet.NetHttpTransport;
import com.google.api.services.vision.v1.Vision;
import com.google.api.services.vision.v1.VisionRequestInitializer;
import com.google.api.services.vision.v1.model.AnnotateImageRequest;
import com.google.api.services.vision.v1.model.BatchAnnotateImagesRequest;
import com.google.api.services.vision.v1.model.BatchAnnotateImagesResponse;
import com.google.api.services.vision.v1.model.Feature;
import com.google.api.services.vision.v1.model.Image;
import com.google.api.services.vision.v1.model.TextAnnotation;

import org.apache.commons.io.IOUtils;

import java.io.File;
import java.io.IOException;
import java.io.InputStream;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Arrays;
import java.util.Date;
import java.util.HashMap;
import java.util.TimeZone;
import java.util.Vector;

import static android.provider.MediaStore.EXTRA_OUTPUT;

public class MainActivity extends AppCompatActivity {

    private Button myCam;
    private Button myGallery;
    private ImageView myImageView;

    private String mCurrentPhotoPath = "";
    private static final int REQUEST_EXTERNAL_STORAGE = 1;
    private static String[] PERMISSIONS_STORAGE = {
            Manifest.permission.READ_EXTERNAL_STORAGE,
            Manifest.permission.WRITE_EXTERNAL_STORAGE
    };

    private Vector<String> calendarTitles = new Vector<String>();
    private Vector<Date> calendarDates = new Vector<Date>();

    private static int REQUEST_IMAGE_CAPTURE = 1234;
    private static int REQUEST_GALLERY_PICK = 5678;
    public static final int PERMISSION_GRANTED = 0;
    TextView textView;


    @Override
    protected void onCreate(Bundle savedInstanceState)  {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        myImageView = (ImageView) findViewById(R.id.syllabusImage);
        verifyStoragePermissions(this);
        //cameraView = (SurfaceView) findViewById(R.id.surface);
        textView = (TextView) findViewById(R.id.text);

        //textRecognizer = new TextRecognizer.Builder(getApplicationContext()).build();

        myCam = (Button) findViewById(R.id.camera);
        myGallery = (Button) findViewById(R.id.gallery);

        myCam.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent cameraIntent = new Intent(MediaStore.ACTION_IMAGE_CAPTURE);
                if (cameraIntent.resolveActivity(getPackageManager()) != null) {
                    // Create the File where the photo should go
                    Uri photoFileUri = null;
                    try {
                        photoFileUri = createImageFile();
                    } catch (IOException ex) {
                        // Error occurred while creating the File
                        Log.e("CAMERA CREATE FILE", "IOException");
                        ex.printStackTrace();
                    }
                    // Continue only if the File was successfully created
                    if (photoFileUri != null) {
                        cameraIntent.putExtra(MediaStore.EXTRA_OUTPUT, photoFileUri);
                        startActivityForResult(cameraIntent, REQUEST_IMAGE_CAPTURE);
                    } else{
                        Log.e("CAMERA URI ERROR", "URI Null");
                    }
                }
                Log.d("intent","success");
            }
        });


        myGallery.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(Intent.ACTION_OPEN_DOCUMENT);
                intent.setType("image/*");
                startActivityForResult(intent,REQUEST_GALLERY_PICK);
            }
        });

    }

    public static void verifyStoragePermissions(Activity activity) {
        // Check if we have write permission
        int permission = ActivityCompat.checkSelfPermission(activity, Manifest.permission.WRITE_EXTERNAL_STORAGE);

        if (permission != PackageManager.PERMISSION_GRANTED) {
            // We don't have permission so prompt the user
            ActivityCompat.requestPermissions(
                    activity,
                    PERMISSIONS_STORAGE,
                    REQUEST_EXTERNAL_STORAGE
            );
        }
    }

    @Override
    protected void onActivityResult(int requestCode, int resultCode, @Nullable Intent data) {
        String path = "";
        if (requestCode == REQUEST_IMAGE_CAPTURE && resultCode == RESULT_OK) {

            Log.d("camera","success");
            try {
                Uri uri = Uri.parse(mCurrentPhotoPath);
                myImageView.setImageURI(uri);
                BitmapDrawable bitD = (BitmapDrawable)myImageView.getDrawable();
                Bitmap mImageBitmap = bitD.getBitmap();
                TextRecognizer textRecognizer = new TextRecognizer.Builder(this).build();
                if (!textRecognizer.isOperational()) {
                    Log.w("MainActivity", "Detector Dependencies are not yet available.");
                } else{
                    Frame frame = new Frame.Builder().setBitmap(mImageBitmap).build();
                    SparseArray<TextBlock> items = textRecognizer.detect(frame);
                    Log.d("Number of words", items.size()+"");
                    StringBuilder stringBuilder = new StringBuilder();
                    for (int i=0 ; i<items.size(); i++)
                    {
                        TextBlock item = items.valueAt(i);
                        stringBuilder.append(item.getValue());
                        stringBuilder.append("\n");
                    }
                    textView.setText(stringBuilder.toString());
                    textView.setText(highlightString(textView));
                    textView.setMovementMethod(new ScrollingMovementMethod());


                }
            } catch (Exception e) {
                e.printStackTrace();
            }

        } else if (requestCode == REQUEST_GALLERY_PICK && resultCode == RESULT_OK){
            Uri uri = data.getData();
            myImageView.setImageURI(uri);
            try {
                BitmapDrawable bitD = (BitmapDrawable)myImageView.getDrawable();
                Bitmap mImageBitmap = bitD.getBitmap();
                TextRecognizer textRecognizer = new TextRecognizer.Builder(this).build();
                if (!textRecognizer.isOperational()) {
                    Log.w("MainActivity", "Detector Dependencies are not yet available.");
                }else{

                    Frame frame = new Frame.Builder().setBitmap(mImageBitmap).build();
                    SparseArray<TextBlock> items = textRecognizer.detect(frame);
                    Log.d("Number of words", items.size()+"");
                    StringBuilder stringBuilder = new StringBuilder();
                    for (int i=0 ; i<items.size(); i++)
                    {
                        TextBlock item = items.valueAt(i);
                        stringBuilder.append(item.getValue());
                        stringBuilder.append("\n");
                    }
                    textView.setText(stringBuilder.toString());
                    textView.setText(highlightString(textView));
                    textView.setMovementMethod(new ScrollingMovementMethod());
                }
                //Bitmap mImageBitmap = MediaStore.Images.Media.getBitmap(getContentResolver(), uri);
                //myImageView.setImageBitmap(mImageBitmap);
            } catch (Exception e) {
                e.printStackTrace();
            }
        }
    }
    private Uri createImageFile() throws IOException {
        // Create an image file name
        String timeStamp = new SimpleDateFormat("yyyyMMdd_HHmmss").format(new Date());
        String imageFileName = "JPEG_" + timeStamp + "_";
        File storageDir = Environment.getExternalStoragePublicDirectory(Environment.DIRECTORY_PICTURES);
        File image = File.createTempFile(
                imageFileName,  // prefix
                ".jpg",         // suffix
                storageDir      // directory
        );

        // Save a file: path for use with ACTION_VIEW intents
        mCurrentPhotoPath = "file:" + image.getAbsolutePath();
        return FileProvider.getUriForFile(this, getApplicationContext().getPackageName() + ".my.package.name.provider", image);
    }

    private SpannableString highlightString(TextView mTextView) {
        SpannableString spannableString = new SpannableString(mTextView.getText());
        //Get the previous spans and remove them
        BackgroundColorSpan[] backgroundSpans = spannableString.getSpans(0, spannableString.length(), BackgroundColorSpan.class);

        for (BackgroundColorSpan span: backgroundSpans) {
            spannableString.removeSpan(span);
        }

        String[] months = new String[]{"January ", "February ", "March ", "April ", "May ", "June ",
                "July ","August ","September ","October ", "November ", "December ",
                "Jan ", "Feb ", "Mar ", "Apr ", "May ", "Jun ", "Jul ", "Aug ", "Sep ",
                "Oct ", "Nov ", "Dec ", "Jan. ", "Feb. ", "Mar. ", "Apr. ", "May. ", "Jun. ",
                "Jul. ", "Aug. ", "Sep. ", "Oct. ", "Nov. ", "Dec. "};

        char[] dates = new char[] {'0', '1', '2', '3', '4', '5', '6', '7', '8', '9'};

        String[] events = new String[] {"assignment", "homework", "hw", "exams", "exam", "quiz", "quizzes",
                "midterm", "final", "presentation", "demo", "Assignment","Homework", "HW",
                "Exams", "Exam", "Quiz", "Quizzes", "Midterm", "Final", "Presentation", "Demo"};

        for(int i=0;i<events.length;i++){
            //Search for all occurrences of the month in the string
            String targetEvent = events[i];
            int indexOfEvent = spannableString.toString().indexOf(targetEvent);

            while (indexOfEvent > 0) {

                String calendarTitle = spannableString.subSequence(indexOfEvent, indexOfEvent + targetEvent.length()).toString();
                calendarTitles.add(calendarTitle);

                spannableString.setSpan(new BackgroundColorSpan(Color.YELLOW), indexOfEvent, indexOfEvent + targetEvent.length(), Spanned.SPAN_EXCLUSIVE_EXCLUSIVE);
                indexOfEvent = spannableString.toString().indexOf(targetEvent, indexOfEvent + targetEvent.length());
            }
        }

        for(int i=0;i<months.length;i++){
            //Search for all occurrences of the month in the string
            String targetMonth = months[i];
            int indexOfKeyword = spannableString.toString().indexOf(targetMonth);

            while (indexOfKeyword > 0) {
                CharSequence next2 = String.valueOf(spannableString.charAt(indexOfKeyword+targetMonth.length()+1)); //the next next char after month. e.g. Dec 19, next2 is 9
//                Log.i("next2BBBB", String.valueOf(next2));

                //Highlight months and dates
                if(!(new String(dates).contains(next2))){
                    String date = "2018-" + convertDateFormat(targetMonth) + "-0" + spannableString.subSequence(indexOfKeyword+targetMonth.length(),indexOfKeyword+targetMonth.length()+1).toString();
                    calendarDates.add(parseDate(date));
                    spannableString.setSpan(new BackgroundColorSpan(Color.YELLOW), indexOfKeyword, indexOfKeyword + targetMonth.length() + 1, Spanned.SPAN_EXCLUSIVE_EXCLUSIVE);
                } else {
                    String date = "2018-" + convertDateFormat(targetMonth) + '-' + spannableString.subSequence(indexOfKeyword+targetMonth.length(),indexOfKeyword+targetMonth.length()+2).toString();
                    calendarDates.add(parseDate(date));
                    spannableString.setSpan(new BackgroundColorSpan(Color.YELLOW), indexOfKeyword, indexOfKeyword + targetMonth.length() + 2, Spanned.SPAN_EXCLUSIVE_EXCLUSIVE);
                }

                //Get the next index of the keyword
                indexOfKeyword = spannableString.toString().indexOf(targetMonth, indexOfKeyword + targetMonth.length());
            }
        }

        final int callbackId = 42;
        checkPermissions(callbackId, Manifest.permission.READ_CALENDAR, Manifest.permission.WRITE_CALENDAR);

        for(int i = 0; i < calendarDates.size(); i++){
            addToCalendar(MainActivity.this, calendarTitles.get(i), calendarDates.get(i).getTime(), calendarDates.get(i).getTime() + 1);
        }
        //Set the final text on TextView
        return spannableString;
    }

    public static Date parseDate(String date) {
        try {
//            Log.i("dateAAAAAA", date);
            return new SimpleDateFormat("yyyy-MM-dd").parse(date);
        } catch (ParseException e) {
            e.printStackTrace();
            return null;
        }
    }

    public static String convertDateFormat(String month){
        if(month.equals("January ") || month.equals("Jan. ") || month.equals("Jan ")){
            return "01";
        } else if (month.equals("February ") || month.equals("Feb. ") || month.equals("Feb ")){
            return "02";
        } else if (month.equals("March ") || month.equals("Mar. ") || month.equals("Mar ")){
            return "03";
        } else if (month.equals("April ") || month.equals("Apr. ") || month.equals("Apr ")){
            return "04";
        } else if (month.equals("May ") || month.equals("May. ") || month.equals("May ")){
            return "05";
        } else if (month.equals("June ") || month.equals("Jun. ") || month.equals("Jun ")){
            return "06";
        } else if (month.equals("July ") || month.equals("Jul. ") || month.equals("Jul ")){
            return "07";
        } else if (month.equals("August ") || month.equals("Aug. ") || month.equals("Aug ")){
            return "08";
        } else if (month.equals("September ") || month.equals("Sep. ") || month.equals("Sep ")){
            return "09";
        } else if (month.equals("October ") || month.equals("Oct. ") || month.equals("Oct ")){
            return "10";
        } else if (month.equals("November ") || month.equals("Nov. ") || month.equals("Nov ")){
            return "11";
        } else{
            return "12";
        }

    }


    private static void addToCalendar(Context ctx, final String title, final long dtstart, final long dtend) {
        final ContentResolver cr = ctx.getContentResolver();
        Cursor cursor ;
        if (Integer.parseInt(Build.VERSION.SDK) >= 8 )
            cursor = cr.query(Uri.parse("content://com.android.calendar/calendars"), new String[]{ "_id", CalendarContract.Calendars.CALENDAR_DISPLAY_NAME }, null, null, null);
        else
            cursor = cr.query(Uri.parse("content://calendar/calendars"), new String[]{ "_id", CalendarContract.Calendars.CALENDAR_DISPLAY_NAME }, null, null, null);
        if ( cursor.moveToFirst() ) {
            final String[] calNames = new String[cursor.getCount()];
            final int[] calIds = new int[cursor.getCount()];
            for (int i = 0; i < calNames.length; i++) {
                calIds[i] = cursor.getInt(0);
                calNames[i] = cursor.getString(1);
                cursor.moveToNext();
            }

            AlertDialog.Builder builder = new AlertDialog.Builder(ctx);
            builder.setSingleChoiceItems(calNames, -1, new DialogInterface.OnClickListener() {

                @Override
                public void onClick(DialogInterface dialog, int which) {
                    ContentValues cv = new ContentValues();
                    cv.put("calendar_id", calIds[which]);
                    cv.put("title", title);
                    cv.put("dtstart", dtstart );
                    cv.put("hasAlarm", 1);
                    cv.put("dtend", dtend);
                    cv.put("eventTimezone", TimeZone.getDefault().getID());

                    Uri newEvent ;
                    if (Integer.parseInt(Build.VERSION.SDK) >= 8 )
                        newEvent = cr.insert(Uri.parse("content://com.android.calendar/events"), cv);
                    else
                        newEvent = cr.insert(Uri.parse("content://calendar/events"), cv);

                    if (newEvent != null) {
                        long id = Long.parseLong( newEvent.getLastPathSegment() );
                        ContentValues values = new ContentValues();
                        values.put( "event_id", id );
                        values.put( "method", 1 );
                        values.put( "minutes", 15 ); // 15 minutes
                        if (Integer.parseInt(Build.VERSION.SDK) >= 8 )
                            cr.insert( Uri.parse( "content://com.android.calendar/reminders" ), values );
                        else
                            cr.insert( Uri.parse( "content://calendar/reminders" ), values );

                    }
                    dialog.cancel();
                }

            });

            builder.create().show();
        }
        cursor.close();
        Toast.makeText(ctx, " Successfully Add to Calendar",
                Toast.LENGTH_LONG).show();
    }


    private void checkPermissions(int callbackId, String... permissionsId) {
        boolean permissions = true;
        for (String p : permissionsId) {
            permissions = permissions && ContextCompat.checkSelfPermission(this, p) == PERMISSION_GRANTED;
        }

        if (!permissions)
            ActivityCompat.requestPermissions(this, permissionsId, callbackId);
    }

    @Override
    protected void onSaveInstanceState(Bundle outState) {
        super.onSaveInstanceState(outState);
    }

    @Override
    protected void onDestroy() {
        super.onDestroy();
    }

    @Override
    protected void onPostResume() {
        super.onPostResume();
        // Show your dialog here (this is called right after onActivityResult)
    }

}