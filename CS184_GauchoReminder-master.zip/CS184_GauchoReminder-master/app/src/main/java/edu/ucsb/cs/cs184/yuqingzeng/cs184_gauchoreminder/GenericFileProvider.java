package edu.ucsb.cs.cs184.yuqingzeng.cs184_gauchoreminder;

import android.support.v4.content.FileProvider;

public class GenericFileProvider extends FileProvider {
}
